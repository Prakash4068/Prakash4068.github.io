from django.apps import AppConfig


class PricedropConfig(AppConfig):
    name = 'pricedrop'
