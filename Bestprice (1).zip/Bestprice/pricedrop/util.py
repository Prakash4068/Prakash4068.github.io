import requests
from bs4 import BeautifulSoup
import smtplib
from .models import User
import lxml

def monitor(Link,title_id,price_id,val,confirm,mail):
    url=Link 
    if confirm:
        send_mail(Link,confirm,mail)
    header={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'}
    page=requests.get(url,headers=header)
    soup=BeautifulSoup(page.content,'lxml')
    title=soup.find(id="productTitle").get_text().strip()
    price=soup.find(id="priceblock_ourprice").get_text().strip()
    if ',' in price:
      price=int(price[:price.find(',')])
    else:
      price=int(price)
    if price<=int(val):
        send_mail(Link,False,mail)
        return True 
    return False
def send_mail(Link,confirm,mail):
     server=smtplib.SMTP('smtp.gmail.com',587)
     server.ehlo()
     server.starttls()
     server.ehlo()
     server.login('pricedroped@gmail.com','1234mini1234')
     if not confirm:
       sub="price drop! alert"
       body="check the following link "+Link 
       msg=f"Subject: {sub}\n\n{body}"
     else:
       sub="created Alert"
       body="created alert for the following link "+Link 
       msg=f"Subject: {sub}\n\n{body}"
     server.sendmail('pricedroped@gmail.com',mail,msg)
     server.quit()


