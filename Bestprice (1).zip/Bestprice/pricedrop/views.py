from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from .models import User
from django.http import HttpResponse
import time
from . import util
# Create your views here.

def index(request):
    return render(request, 'pricedrop/index.html')

def login_view(request):
    message=''
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['pswrd']
        user=authenticate(request,username=username,password=password)
        if not user:
             message='Invalid username or password'
             return  render(request, 'pricedrop/index.html',{'message':message})
        login(request,user)
        return render(request,'pricedrop/add.html')
    return render(request, 'pricedrop/index.html')
def logout_view(request):
    logout(request)
    return render(request,'pricedrop/index.html')

def register(request):
     if request.method=="POST":
        username=request.POST['username']
        email=request.POST['Email']
        password=request.POST['pswrd']
        con_password=request.POST['cpswrd']
        message=''
        if password!=con_password:
            message='password must match'
            return render(request,'pricedrop/register.html',{'message':message})
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "pricedrop/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return render(request,'pricedrop/add.html')
     else:
         return render(request,'pricedrop/register.html')
def add(request):
     if request.method=='POST':
         product_link=request.POST['Link']
         product_name=request.POST['nameid']
         product_price=request.POST['priceid']
         val=request.POST['val']
         confirm=True
         mail=request.user.email
         while True:
            drop=util.monitor(product_link,product_name,product_price,val,confirm,mail)
            if drop:
                break  
            confirm=False
            time.sleep(1000)
         return render(request,'pricedrop/succes.html')
     else:
      return render(request,'pricedrop/add.html')


